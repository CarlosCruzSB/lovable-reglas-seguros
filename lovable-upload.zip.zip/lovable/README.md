# Lovable UI - Reglas de Seguros

Interfaz simple para ingresar reglas en lenguaje natural y mostrarlas como vista previa.