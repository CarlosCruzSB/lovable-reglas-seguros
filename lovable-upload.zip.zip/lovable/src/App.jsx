import React, { useState } from "react";
import RuleInput from "./components/RuleInput";
import RulePreview from "./components/RulePreview";

export default function App() {
  const [rules, setRules] = useState([]);

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Reglas de Negocio - Seguros</h1>
      <RuleInput rules={rules} setRules={setRules} />
      <RulePreview rules={rules} />
    </div>
  );
}
