import React from "react";

export default function RulePreview({ rules }) {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Vista previa de reglas</h2>
      <ul className="list-disc pl-5 space-y-1">
        {rules.map((rule, index) => (
          <li key={index}>{rule}</li>
        ))}
      </ul>
    </div>
  );
}
