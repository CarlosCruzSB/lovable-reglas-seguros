import React, { useState } from "react";

export default function RuleInput({ rules, setRules }) {
  const [input, setInput] = useState("");

  const handleAdd = () => {
    if (input.trim()) {
      setRules([...rules, input.trim()]);
      setInput("");
    }
  };

  return (
    <div className="mb-6">
      <textarea
        className="w-full p-2 border rounded"
        rows={3}
        placeholder="Escribe una nueva regla en lenguaje natural..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button onClick={handleAdd} className="mt-2 px-4 py-2 bg-blue-500 text-white rounded">
        Agregar regla
      </button>
    </div>
  );
}
